ZX Virtual Keyboard
-------------------

A touch-based ZX Spectrum style on screen keyboard for Windows.

Perfect for fuse or Zesarux!

Keyboard is very slightly too small, perfect for that proper ZX Spectrum 
experience.

Written in Qt, to build from source use QMake (mingw probably required, I got
linker errors with Visual Studio 2015).

Follow me on twitter @jimblimey !
